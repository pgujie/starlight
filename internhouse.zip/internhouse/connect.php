<?php
         $dbhost = 'localhost:3306';
         $dbuser = 'root';
         $dbpass = '';
         $conn = mysqli_connect($dbhost, $dbuser, $dbpass,'internhouse');

         if(!$conn ){
            die('Could not connect: ' . mysqli_error());
         }

?>
