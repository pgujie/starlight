	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
<?php
include 'header.php';
?><body><?php
if (isset($_GET['search'])) {
	include 'search.php';
}
elseif (isset($_GET['jobs'])) {
	include 'jobs.php';
}
elseif (isset($_GET['houses'])) {
	include 'houses.php';
}
elseif (isset($_GET['houses'])) {
	include 'mail.php';
}
 else {
	include 'main.php';
}
include 'footer.php';
mysqli_close($conn); ?>
		</body>
	</html>
