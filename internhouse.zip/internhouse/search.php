
<!-- start banner Area -->
<section class="banner-area relative" id="home">
  <div class="overlay overlay-bg"></div>
  <div class="container">
    <div class="row search-page-top d-flex align-items-center justify-content-center">
      <div class="banner-content col-lg-12">
        <h1 class="text-white">
          Search Results
        </h1>
        <p class="text-white link-nav">
          <a href="index.html">Home </a> <span class="lnr lnr-arrow-right"></span> <a href="search.html"> Job details page</a>
        </p>
        <form class="serach-form-area" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="get">
          <div class="row justify-content-center form-wrap">
            <div class="col-lg-4 form-cols">
              <input type="text" class="form-control" name="key" placeholder="Search what you want...">
            </div>
            <div class="col-lg-3 form-cols">
              <div class="default-select" id="default-selects">
                <select name="area">
                  <option value="1">Select area</option>
                  <?php
                  $sql = 'SELECT location FROM post';
                 $result = mysqli_query($conn, $sql);

                 if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                       echo "Name: " . $row["location"]. "<br>";
                       echo "<option value=".$row["location"].">". $row["location"]."</option>";
                    }
                 }?>
                    <option value='Local'>Anywhere in Harare</option>
                    <option value='National'>Anywhere in Zimbabwe</option>
                </select>
              </div>
            </div>
            <div class="col-lg-3 form-cols">
              <div class="default-select" id="default-selects2">
                <select name="category">
                  <option value="All" selected>All Category</option>
                  <option value="Accommodation">Accommodation</option>
                  <option value="Attatchment">Attatchment</option>
                </select>
              </div>
            </div>
            <div class="col-lg-2 form-cols">
                <button type="submit" name="search" class="btn btn-info">
                  <span class="lnr lnr-magnifier"></span>
                </button>
            </div>
          </div>
        </form>
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6">
              <div class="single-feature">
                <h2>Accommodation</h2>
                <?php $count = 6; ?>
                <p><?php echo $count.'Accommodation results found for <span>"'. $_GET["key"] ?>"</span></p>
                <hr>
                <p>

                </p>
              </div>
            </div>
            <div class="col-lg-6 col-md-6">
              <div class="single-feature">
                <h2>Attatchment</h2>
                <?php $count3 = 46; ?>
                <p><?php echo $count3.' Attatchment results found for <span>"'. $_GET["key"] ?>"</span></p>
                <hr>
                <p>

                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End banner Area -->
