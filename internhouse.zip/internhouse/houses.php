<?php
include 'header.php';
?>
  <section class="banner-area relative" id="home">
    <div class="overlay overlay-bg"></div>
    <div class="container">
      <div class="row d-flex align-items-center justify-content-center">
        <div class="about-content col-lg-12">
          <h1 class="text-white">
            Look for a house to rent
          </h1>
          <p class="text-white link-nav"><a href="index.html">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="#content"> Houses</a></p>
        </div>
      </div>
    </div>
  </section>

<section id="content">
  <?php
  if (isset($_SESSION['role'])) {
    echo "Welcome back, ".$_SESSION['name'];

  } else {
    echo "Not allowed to view this page";
  }
   include 'footer.php';
   ?>
</section>
