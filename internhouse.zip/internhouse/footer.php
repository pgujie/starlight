<!-- start footer Area -->
<footer class="footer-area section-gap">
  <div class="container">
    <div class="row">
      <div class="col-lg-6  col-md-12">
        <div class="single-footer-widget newsletter">
          <h6>Get in touch!</h6>
          <p>You can trust us. we only send when there are new jobs or accommodation offers, not a single spam.</p>
          <div id="mc_embed_signup">
            <form target="_blank" novalidate="true" action="mail.php" method="post" class="form-inline">
              <div class="form-group row" style="width: 100%">
                <div class="col-lg-8 col-md-12">
                  <input name="name" placeholder="Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email '" required="" type="text">
                  <span>We would love to call you by name.</span>
                  <input name="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email '" required="" type="email">
                  <span>We would love to get in touch too.</span>
                  <input name="message" placeholder="Your message to us" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your message to us... '" required="" type="textarea">
                </div>
                <div class="col-lg-4 col-md-12">
                  <button type="submit" name="submit" class="nw-btn primary-btn">Subscribe<span class="lnr lnr-arrow-right"></span></button>
                </div>
              </div>
              <div class="info"></div>
            </form>
          </div>
        </div>
      </div>
      <div class="col-lg-6  col-md-12">
        <div class="single-footer-widget mail-chimp">
          <h6 class="mb-20"><i class="fa fa-phone"></i> Support Lines</h6>
          <ul class="">
            <li> Prince - +263 77</li>
            <li> Brian - +263 77</li>
            <li><i class="fa fa-mobile"></i> Joseph - +263 77 184 6212</li>
          </ul>
        </div>
      </div>
    </div>

    <div class="row footer-bottom d-flex justify-content-between">
      <h5 class="col-lg-8 footer-text m-0 text-white">
        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This is a product of <a href="http://www.starlight.co.zw" title="Starlight">Starlight Technologies</a>
      </h5>
        <div class="col-lg-4 footer-social">
          <a href="#"><i class="fa fa-facebook"></i></a>
          <a href="#"><i class="fa fa-twitter"></i></a>
          <a href="#"><i class="fa fa-dribbble"></i></a>
          <a href="#"><i class="fa fa-behance"></i></a>
        </div>
    </div>
  </div>
</footer>
<!-- End footer Area -->
<script src="js/vendor/jquery-2.2.4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/vendor/bootstrap.min.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  <script src="js/easing.min.js"></script>
<script src="js/hoverIntent.js"></script>
<script src="js/superfish.min.js"></script>
<script src="js/jquery.ajaxchimp.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.sticky.js"></script>
<script src="js/jquery.nice-select.min.js"></script>
<script src="js/parallax.min.js"></script>
<script src="js/mail-script.js"></script>
<script src="js/main.js"></script>
