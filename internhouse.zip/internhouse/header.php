<?php
   ob_start();
   session_start();
   error_reporting(E_ALL);
   ini_set("display_errors", 1);
    include 'connect.php';
?>
<head>
  <!-- Mobile Specific Meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Favicon-->
  <link rel="shortcut icon" href="img/fav.png">
  <!-- Author Meta -->
  <meta name="author" content="codepixer">
  <!-- Meta Description -->
  <meta name="description" content="">
  <!-- Meta Keyword -->
  <meta name="keywords" content="">
  <!-- meta character set -->
  <meta charset="UTF-8">
  <!-- Site Title -->
  <title>  Starlight Technology</title>

  <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
    <!--
    CSS
    ============================================= -->
    <link rel="stylesheet" href="css/linearicons.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/main.css">
  </head>
<header id="header" id="home">
  <div class="container">
    <div class="row align-items-center justify-content-between d-flex">
      <div id="logo">
        <a onclick="window.open('index.php','_self')"><img src="img/logo.png" alt="" title="" /></a>
      </div>
      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a onclick="window.open('index.php','_self')">Home</a></li>
          <li class="menu-has-children"><a>Category</a>
            <ul>
              <li><a onclick="window.open('houses.php','_self')">Accommodation</a></li>
              <li><a onclick="window.open('jobs.php','_self')">Attatchment</a></li>
              <li><a onclick="window.open('http://starlight.co.zw')">More products of Starlight...</a></li>
            </ul>
          </li>
          <li><a onclick="window.open('about.php','_self')">About</a></li>
          <?php
                      if (isset($_POST['login']) && !empty($_POST['uname']) && !empty($_POST['psw'])) {
                        $user = $_POST['uname'];
                        $psw = $_POST['psw'];
                        $login = "SELECT * FROM `users` WHERE `Username` = '".$user."' and  `PasswordHash` = '".md5($psw)."'";
                        $loggedin = mysqli_query($conn, $login);
                        if ($loggedin) {
                          $thisuser = mysqli_fetch_assoc($loggedin);
                          $_SESSION['valid'] = true;
                          $_SESSION['timeout'] = time();
                          $_SESSION['username'] = $thisuser["Username"];
                          $_SESSION['name'] = $thisuser["FullName"];
                          $_SESSION['role'] = $thisuser["UserRole"];

                         }else {
                           ?>
                           <li><a class="ticker-btn" style="color:red" onclick="document.getElementById('login').style.display='block'">Could not login></a></li>
                           <?php
                         }
                      }
                        if(isset($_POST['logout'])){
                          unset($_SESSION["username"]);
                          unset($_SESSION["name"]);
                          unset($_SESSION["role"]);

                        }
                        if(isset($_POST['register'])){

                          $name = $_POST['name'];
                          $uname = $_POST['uname'];
                          $pwd = $_POST['pwd'];
                          $role = $_POST['role'];
                          $insert = "INSERT INTO users(`Username`, `FullName`, `PasswordHash`, `UserRole`) VALUES ('".$uname."','".$name."','".md5($pwd)."','".$role."')";
                          if (mysqli_query($conn, $insert)) {
                            $_SESSION['username'] = $uname;
                            $_SESSION['name'] = $name;
                            $_SESSION['role'] = $role;
                          }
                          else {
                            ?>
                            <li><a class="ticker-btn" style="color:red" onclick="document.getElementById('login').style.display='block'">Failed to logon</a></li>
                            <?php
                          }
                        }

                        if (isset($_SESSION['name'])) {
                          if($_SESSION["role"] == 'Student' ){
                            ?><li><a onclick="window.open('jobs.php','_self')">Find a job</a></li>
                            <li><a onclick="window.open('houses.php','_self')">Find a house</a></li><?php
                          }
                          if($_SESSION['role'] == 'Employer' ){
                            ?><li><a onclick="window.open('applications.php','_self')">Student applications</a></li><?php
                          }
                          if($_SESSION['role'] == 'LandLord' ){
                          ?> <li><a onclick="window.open('applications.php','_self')">Accommodation requests</a></li><?php
                          }
                          ?>

                          <li class="menu-has-children"><a style="background: #e00"><?php echo $_SESSION['name'];  ?></a>
                            <ul>
                              <li><a style="border-bottom:2px solid #e00; color:#e00;"><?php echo $_SESSION['role'];?></a> </li>
                              <li><a onclick="document.getElementById('login').style.display='block'">Manage</a></li>
                              <li>
                                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
                                  <button class="close" type="submit" name="logout"><a>Logout</a></button>
                              </form>
                              </li>
                            </ul>
                          </li>
                          <?php
                        }else {
                          ?>
                          <li><a class="ticker-btn" onclick="document.getElementById('mc_embed_signup').style.display='block'">Signup</a></li>
                          <li><a class="ticker-btn" onclick="document.getElementById('login').style.display='block'">Login</a></li>
                          <?php
                        }
                   ?>

        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </div>
</header>
<div id="login" class="modal">

  <form class="modal-content animate form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
<div class="text-center modal-header">
  <h3 >Login</h3>
</div>
    <hr>
    <div class="container">
      <label for="uname"><b>Username</b></label>
      <input class="form-control" type="text" placeholder="Username" name="uname" required>
      <label for="psw"><b>Password</b></label>
      <input class="form-control" type="password" placeholder="Password" name="psw" required>
      <label>
        <input type="checkbox" class="form-control" checked="checked" name="remember"> Remember me
      </label>
    </div>
    <br>
    <div style="margin:0 auto; height: 50px;" class="row col-lg-8">
      <button type="button" onclick="document.getElementById('login').style.display='none'" class="col-lg-5 btn btn-default">Cancel</button>
      <div class="col-lg-2">
      </div>
      <button type="submit" name="login" class="col-lg-5 btn btn-outline-warning">Login</button>
    </div>
    <footer class="text-center modal-footer" style=""><i>Powered By <a onclick="window.open('http://www.starlight.co.zw')">Starlight</a> </i></footer>
  </form>
</div>
<div id="mc_embed_signup" class="modal">

  <form class="modal-content animate form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
<div class="text-center modal-header">
  <h3 >Signup</h3>
</div>
    <hr>
    <div class="container">
      <label for="name"><b>Full Name</b></label>
      <input class="form-control" type="text" placeholder="Username" name="name" required>
      <label for="uname"><b>Username</b></label>
      <input class="form-control" type="text" placeholder="Username" name="uname" required>
      <label for="pwd"><b>Password</b></label>
      <input class="form-control" type="password" placeholder="Password" name="pwd" required>
      <label for="cpsw"><b>Confirm Password</b></label>
      <input class="form-control" type="password" placeholder="Confirm Password" name="cpsw" required>
      <label for="role"><b>Which one defines you?</b></label>
      <select class="form-select default-selects"  name="role" required>
        <option value="Student">Student</option>
        <option value="Employer">Employer</option>
        <option value="LandLord">LandLord</option>
      </select>
    </div>
    <br>
    <div style="margin:0 auto; height: 50px;" class="row col-lg-8">
      <button type="button" height="50" onclick="document.getElementById('mc_embed_signup').style.display='none'" class="col-lg-5 btn btn-default">Cancel</button>
      <div class="col-lg-2">
      </div>
      <button type="submit" name="register" class="col-lg-5 btn btn-outline-warning">Register</button>
    </div>
    <footer class="text-center modal-footer" style=""><i>Powered By <a onclick="window.open('http://www.starlight.co.zw')">Starlight</a> </i></footer>
  </form>
</div>
<script>
var modal = document.getElementsByClassName('modal');

window.onclick = function(event) {
    if (event.target == modal[0] || event.target == modal[1]) {
        modal[0].style.display = "none";
        modal[1].style.display = "none";
    }
}
</script>
