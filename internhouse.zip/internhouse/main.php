<!-- start banner Area -->
<section class="banner-area relative" id="home">
  <div class="overlay overlay-bg"></div>
  <div class="container">
    <div class="row fullscreen d-flex align-items-center justify-content-center">
      <div class="banner-content col-lg-12">
        <div class="row">
          <h2 class="text-white col-lg-6">
            <span>1500+</span>
            <br/>
             Jobs posted this week
          </h2>
          <h2 class="text-white col-lg-6">
            <span>1300+</span>
            <br/>
            Houses on offer this week
          </h2>
        </div>

        <form class="serach-form-area" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="get">
          <div class="row justify-content-center form-wrap">
            <div class="col-lg-4 form-cols">
              <input type="text" class="form-control" name="key" placeholder="Search what you want...">
            </div>
            <div class="col-lg-3 form-cols">
              <div class="default-select" id="default-selects">
                <select name="area">
                  <option value="All">Select area</option>
                  <?php
                  $sql = 'SELECT * FROM post';
                 $result = mysqli_query($conn, $sql);

                 if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                       echo "Name: " . $row["location"]. "<br>";
                       echo "<option value=".$row["location"].">". $row["location"]."</option>";
                    }
                 }?>
                    <option value='Local'>Anywhere in Harare</option>
                    <option value='National'>Anywhere in Zimbabwe</option>
                </select>
              </div>
            </div>
            <div class="col-lg-3 form-cols">
              <div class="default-select" id="default-selects2">
                <select name="category">
                  <option value="1" selected>All Category</option>
                  <option value="2">Accommodation</option>
                  <option value="3">Attatchment</option>
                </select>
              </div>
            </div>
            <div class="col-lg-2 form-cols">
                <button type="submit" name="search" class="btn btn-info">
                  <span class="lnr lnr-magnifier"></span>
                </button>
            </div>
          </div>
        </form>
        <p class="text-white"> <span>Search examples:</span> IT Company, accounting, 2 rooms, sharing... etc</p>
      </div>
    </div>
  </div>
</section>
<!-- End banner Area -->
<!-- Start features Area -->
<section class="features-area">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-6">
        <div class="single-feature">
          <h2>Accommodation</h2>
          <hr>
          <p>
            Look for it, advertise it, get all your accommodation services in one place...
          </p>
        </div>
      </div>
      <div class="col-lg-6 col-md-6">
        <div class="single-feature">
          <h2>Attatchment</h2>
          <hr>
          <p>
            Search, apply and post news, articles and places for attatchment...
          </p>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End features Area -->

<!-- Start popular-post Area -->
<section class="popular-post-area pt-100">
  <div class="container">
    <div class="row align-items-center">
      <div id="popular" class="active-popular-post-carusel">
        <?php
        $sql = 'SELECT * FROM post';
       $result = mysqli_query($conn, $sql);

       if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
            $link = $row["Type"] == "Accommodation" ? "jobs.php" : "houses.php";
             echo '<div class="single-popular-post d-flex flex-row">
             <div class="single-popular-post d-flex flex-row">
               <div class="thumb">
                 <img src="img/p2.png" alt="">
               </div>
               <div class="details">
                 <a href="#"><h4>'.$row["Type"].'</h4></a>
                 <h6>'.$row["Sponsor"].'</h6>
                 <span>'.$row["Address"].', '.$row["Location"].'</span>
                 <hr>
                 <p>'.$row["Advert"].'</p>
                 <hr>
                 <a class="text-uppercase" href="'.$link.'#'.$row["ID"].'">view '.$row["Type"].' post</a>
               </div>
             </div>
       </div>
             ';
          }
       }
else {
  echo '<div class="single-popular-post d-flex flex-row">
    <div class="thumb">
      <img src="img/p2.png" alt="">
    </div>
    <div class="details">
      <a href="#"><h4>No posts</h4></a>
      <h6>Starlight technologies, Harare</h6>
      <p class="generic-blockquote">
      Feel free to use our product and post your accommodation, attatchment adverts.
      </p>
      <hr>
      <a class="text-uppercase" href="#">view job post</a>
    </div>
  </div>';
}
       ?>

      </div>
    </div>
  </div>
</section>
<!-- End popular-post Area -->

<!-- Start feature-cat Area -->
<section class="feature-cat-area pt-100" id="category">
  <div class="container">
    <div class="row d-flex justify-content-center">
      <div class="menu-content pb-60 col-lg-10">
        <div class="title text-center">
          <h1 class="mb-10">Featured Job Categories</h1>
          <p>Who are in extremely love with eco friendly system.</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="single-fcat">
          <a href="category.html">
            <img src="img/o1.png" alt="">
          </a>
          <p>Accounting</p>
        </div>
      </div>
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="single-fcat">
          <a href="category.html">
            <img src="img/o2.png" alt="">
          </a>
          <p>Development</p>
        </div>
      </div>
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="single-fcat">
          <a href="category.html">
            <img src="img/o3.png" alt="">
          </a>
          <p>Technology</p>
        </div>
      </div>
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="single-fcat">
          <a href="category.html">
            <img src="img/o4.png" alt="">
          </a>
          <p>Media & News</p>
        </div>
      </div>
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="single-fcat">
          <a href="category.html">
            <img src="img/o5.png" alt="">
          </a>
          <p>Medical</p>
        </div>
      </div>
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="single-fcat">
          <a href="category.html">
            <img src="img/o6.png" alt="">
          </a>
          <p>Goverment</p>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End feature-cat Area -->




<!-- Start callto-action Area -->
<section class="callto-action-area section-gap" id="join">
  <div class="container">
    <div class="row d-flex justify-content-center">
      <div class="menu-content col-lg-9">
        <div class="title text-center">
          <h1 class="mb-10">Join us today without any hesitation</h1>
          <p class="">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore  et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
          <a class="primary-btn" href="#">I am a Candidate</a>
          <a class="primary-btn" href="#">Request Free Demo</a>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End calto-action Area -->
