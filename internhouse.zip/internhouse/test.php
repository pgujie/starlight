<?php
echo md5("1234")."<br>";
echo md5("1234")."<br>";
echo md5("1234")."<br>";
echo md5("1234")."<br>";
echo md5("1234")."<br>";
echo md5("1234")."<br>";
echo md5("1235")."<br>";
 ?>
 <?php
 include 'header.php';
 $sql = 'SELECT * FROM post';
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
   while($row = mysqli_fetch_assoc($result)) {
      echo '<div class="single-popular-post d-flex flex-row">
      <div class="single-popular-post d-flex flex-row">
        <div class="thumb">
          <img src="img/p2.png" alt="">
        </div>
        <div class="details">
          <a href="#"><h4>'.$row["Type"].'</h4></a>
          <h6>'.$row["Sponsor"].'</h6>
          <h6>'.$row["Address"].', '.$row["Location"].'</h6>
          <p class="generic-blockquote">'.$row["Advert"].'</p>
          <hr>
          <a class="text-uppercase" href="#">view '.$row["Type"].' post</a>
        </div>
      </div>
</div>
      ';
   }
}?>
